//==================================================================-
/*
/file   Registers.cpp
/author Jakob McFarland
/date   1/20/19
/brief

This is the specification file for all master register functions.

*/
//==================================================================-

#pragma once

namespace Registers
{
	//master component register
	void RegisterComponents();
}